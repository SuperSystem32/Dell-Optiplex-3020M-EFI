# Dell-Optiplex-3020M-EFI
 Dell Optiplex 3020M EFI, Opencore 0.9.9
